//
//  TipCalculatorBrain.swift
//  Tip Calculator
//
//  Created by Joshua Aaron Flores Stavedahl on 10/17/17.
//  Copyright © 2017 Northern Illinois University. All rights reserved.
//

import Foundation

class tipCalculatorBrain {
    
}
